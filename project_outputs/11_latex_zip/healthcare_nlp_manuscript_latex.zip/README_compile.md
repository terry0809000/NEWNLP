# Compile Instructions

This package was generated for a PLOS ONE-style research manuscript. It uses a standard LaTeX `article` class plus common packages (`graphicx`, `booktabs`, `hyperref`, `float`, `caption`).

Recommended local compilation:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If using the Codex bundled LaTeX compiler:

```bash
python C:/Users/Terry Yu/.codex/plugins/cache/openai-bundled/latex/0.2.0/scripts/compile_latex.py C:/Users/Terry Yu/Documents/Healthcare_NLP_CPU_Project/latex/main.tex
```
